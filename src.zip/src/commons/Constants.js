export const paths = {
    PLAYGROUND : "/",
    SURVEY:"/survey"
}

export const storageKeys = {
    SURVEY_ID:"surveyId"
}