import React, { Component } from 'react';


class Playground extends Component{


    render(){
        return (
            <div>
                Playground
            </div>
        )
    }
}

export default Playground;